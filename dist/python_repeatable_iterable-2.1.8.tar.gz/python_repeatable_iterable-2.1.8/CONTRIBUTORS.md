# python-repeatable-iterable contributors

Laurent Lyaudet, creator of the package

David Salvisberg, suggested huge improvements here:
<https://discuss.python.org/t/repeatableiterable-type/42106/1>.

